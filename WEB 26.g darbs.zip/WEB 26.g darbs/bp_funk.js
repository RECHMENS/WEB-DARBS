function calculate() {
    let sys = Number(document.getElementById("sistoliskais").value);
    let dia = Number(document.getElementById("diastoliskais").value);

    if (!sys || !dia) {
        alert("Lūdzu, ievadiet gan sistoliskās, gan diastoliskās vērtības.");
        return;
    }

    let pp = sys - dia;
    document.getElementById("pp").innerText = pp + " mmHg";

    let map = Math.round(dia + pp / 3);
    document.getElementById("map").innerText = map + " mmHg";

    let classification = "";
    let note = "";
    let badge = document.getElementById("badge");

    if (sys >= 180 || dia >= 120) {
        classification = "Hipertensīvā krīze";
        note = "Seek medical attention immediately.";
        badge.innerText = "krīze";
        badge.style.background = "#ffb3b3";
        badge.style.color = "#a10000";
    } else if (sys >= 140 || dia >= 90) {
        classification = "Hipertensijas 2. stadija";
        badge.innerText = "2. stadija";
        badge.style.background = "#ffd4c1";
        badge.style.color = "#b05200";
    } else if (sys >= 130 || dia >= 80) {
        classification = "Hipertensijas 1. stadija";
        badge.innerText = "1. stadija";
        badge.style.background = "#ffe9b8";
        badge.style.color = "#b28700";
    } else if (sys >= 120 && dia < 80) {
        classification = "Paaugstināts";
        badge.innerText = "Paaugstināts";
        badge.style.background = "#e8f4ff";
        badge.style.color = "#005bbb";
    } else {
        classification = "Normal";
        badge.innerText = "Normal";
        badge.style.background = "#d7f7d9";
        badge.style.color = "#2d7c35";
    }

    document.getElementById("klasifikācija").innerText = classification;
}

function loadSample() {
    document.getElementById("sistoliskais").value = 128;
    document.getElementById("diastoliskais").value = 82;
    document.getElementById("pulss").value = 72;
    calculate();
}

function resetAll() {
    document.getElementById("sistoliskais").value = "";
    document.getElementById("diastoliskais").value = "";
    document.getElementById("pulss").value = "";
    document.getElementById("vecums").value = "";

    document.getElementById("klasifikācija").innerText = "—";
    document.getElementById("map").innerText = "— mmHg";
    document.getElementById("pp").innerText = "— mmHg";

    let badge = document.getElementById("badge");
    badge.innerText = "Normal";
    badge.className = "badge normal";
}